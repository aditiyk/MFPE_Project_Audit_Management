INSERT INTO project_manager_details(id, name, username, password, project_name) VALUES (1, 'Teja Sri', 'ts', 'ts1234', 'Project-1');
INSERT INTO project_manager_details(id, name, username, password, project_name) VALUES (2, 'Srivalli', 'sv', 'sv1234', 'Project-2');
INSERT INTO project_manager_details(id, name, username, password, project_name) VALUES (3, 'Ishwarya', 'is', 'is1234', 'Project-3');
INSERT INTO project_manager_details(id, name, username, password, project_name) VALUES (4, 'Aditi', 'ad', 'ad1234', 'Project-4');
INSERT INTO project_manager_details(id, name, username, password, project_name) VALUES (5, 'Mohan', 'mn', 'mn1234', 'Project-5');