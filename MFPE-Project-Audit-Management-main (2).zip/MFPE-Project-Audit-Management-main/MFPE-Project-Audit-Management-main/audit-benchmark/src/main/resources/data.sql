INSERT INTO audit_benchmark(benchmark_id,audit_type,benchmark_no_answers) VALUES (1,'Internal',3);
INSERT INTO audit_benchmark(benchmark_id,audit_type,benchmark_no_answers) VALUES (2,'SOX',1);